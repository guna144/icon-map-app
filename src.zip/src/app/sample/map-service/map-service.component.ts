import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as leaflet from 'leaflet';

@Component({
  selector: 'map-service',
  templateUrl: './map-service.component.html',
  styleUrls: ['./map-service.component.css']
})
export class MapServiceComponent implements OnInit {

  map  : any;
  data : any[];
  cluster;

  constructor(private _http : HttpClient){
  
  }

  ngOnInit() {
    this._http.get('./assets/data/address.json').subscribe(
      val => {
        this.data = val as string[];        
        this.loadMap();
      });
  }

  loadMap(){
    
    this.map = leaflet.map("map").fitWorld();
    let latlng = leaflet.latLng(25.076491599999997, 55.15415050000001); //-37.89, 175.46);
    let markerIcon = leaflet.icon({
        iconUrl: './assets/images/oil.png',
        iconSize:     [25, 41], // size of the icon
        shadowSize:   [41, 41] // size of the shadow
      });


    leaflet.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
        attribution : "VisionValley",
        maxZoom : 17
    }).addTo(this.map);
   
    /**
     * This is for default locate your location on the map loading and other features
     */
    // this.map.locate({
    //   setView : true,
    //   maxZoom : 10
    // }); //.on("locationfound",(e) => {
    //   let markerGroup = leaflet.featureGroup();
    //   let marker      = leaflet.marker([e.latitude, e.longitude], {icon : markerIcon}).on('click', () => {
    //       console.log("Marker clicked on lat lon : "+e.latitude, e.longitude);
    //   });
    //   markerGroup.addLayer(marker);
    //   //this.map.addLayer(markerGroup);
    // });

    /**
     * This is for click on the map then you will get the latitude and longitude 
     */
    this.map.on('click', (e) => { console.log("********** : "+e.latlng); });

     this.cluster = leaflet.markerClusterGroup();
    let iconURL = "./assets/images/oil.png";

    for (let i = 0; i < this.data.length; i++) {              
      let latitudeLongitude = this.data[i];
      let title = latitudeLongitude[2];
      let tankLevel = latitudeLongitude[3];
      if(tankLevel != null && tankLevel != ""){
        if(tankLevel > 0 && tankLevel <=15 ) iconURL = "./assets/images/red.png"; // console.log("Red : "+latitudeLongitude[0], latitudeLongitude[1] + " : "+markerIcon);
        if(tankLevel > 15 && tankLevel <=30 ) iconURL = "./assets/images/yellow.png"; // console.log("Yellow : "+latitudeLongitude[0], latitudeLongitude[1]);
        if(tankLevel > 30 ) iconURL = "./assets/images/green.png"; //console.log("Green : "+latitudeLongitude[0], latitudeLongitude[1]);
      }else
        iconURL = "./assets/images/oil.png"; 
      let marker1 = leaflet.marker(leaflet.latLng(latitudeLongitude[0], latitudeLongitude[1]),
                        {icon : leaflet.icon(
                                { iconUrl : iconURL , 
                                iconSize:     [25, 41], // size of the icon
                                shadowSize:   [41, 41] // size of the shadow
                               }) , title: title });
      
      marker1.bindPopup(title).openPopup();
      this.cluster.addLayer(marker1);
      
    }

    /**
     * This is for default open popup with message
     */
    // var popup = leaflet.popup()
    // .setLatLng(latlng)
    // .setContent('<p>Hello world!<br />This is a nice popup.</p>')
    // .openOn(this.map);


     this.map.addLayer(this.cluster);
     
  }
}
