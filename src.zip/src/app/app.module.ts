import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { MapServiceComponent } from './sample/map-service/map-service.component';
import { LeafletMarkerClusterModule } from '@asymmetrik/ngx-leaflet-markercluster';

@NgModule({
  declarations: [
    AppComponent,
    MapServiceComponent
  ],
  imports: [
    BrowserModule, HttpClientModule, LeafletMarkerClusterModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
